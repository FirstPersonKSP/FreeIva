# Free IVA

Work in progress mod for Kerbal Space Program which allows getting out of your seat and moving around the vessel while on IVA.

See the [wiki](https://github.com/pizzaoverhead/FreeIva/wiki) for full details.

Free IVA is licenced under GPL v2. See [LICENSE](https://github.com/pizzaoverhead/FreeIva/blob/main/LICENSE) for details. All sound model and texture assets (.wav, .mu,  .dae, .tga etc.) are licensed All Rights Reserved.
